# 后端 SDK API

按接口查阅串口、模拟数据、帧解析、点位配置、后端通讯和存储。每个接口列出用途、调用方式、参数、返回值、示例与注意事项；语言下拉框同时切换正文与本页目录。

快速接入的 `readProduct / createWS` 分别调用本页的 `connectProduct / serveDevice`；采集与下载也复用同一服务方法。查看[五函数与基础 API 对应表](./CUSTOM.md#quick-to-base)，或直接查下方参数。

**0.5.0 新增：** Node 分包手套支持手动选口与自动识别。手动传 `path + side`；自动调用 `readProduct({ product: 'glove', onData, onError })`，内部复用基础 `connectProduct()` → `scanProductPorts()`。五个快速函数保持不变；0.4.0 仍需手动配置，自动识别要求升级到 0.5.0。

## 环境与导入 {#setup}

真实设备先完成[驱动安装](./DRIVERS.md)与[SDK 授权](./LICENSE.md)。CH34x 驱动缺失时系统不能提供串口；Windows 使用 [CH341SER.EXE](https://shroom.jq-industries.com/drive/CH341SER.EXE)，macOS 使用 [CH34xVCPDriver.zip](https://shroom.jq-industries.com/drive/CH34xVCPDriver.zip)。安装后重插设备、重启采集程序再查询。SDK 许可证不按设备型号限制产品接口或通用串口，但产品协议仍需匹配实际硬件。

<div data-sdk-language="node">

### Node.js 入口 {#node-import}

使用 Node.js 18+。在自己的业务项目中运行：

```bash
npm install shroom-sdk
```

```js
import { Shroom, BackendSdkClient, createFramer, decodeFrame, resolveShape,
  getLayout, listLayouts, getProduct, listProducts,
  connectGlove, connectHandPad, connectProduct, listDeviceProducts, listPorts, serveDevice,
  ShroomError, asShroomError, ERROR_CODES } from 'shroom-sdk/node';
```

示例保存为业务项目的 `.mjs` 文件，用 `node 文件名.mjs` 运行。本页其他示例中的 `./node/index.js` 是源码 ZIP 写法，npm 用户改为 `shroom-sdk/node`；使用 ZIP 时，在解压目录执行 `npm ci` 后运行。真实串口依赖 `serialport`；快速 WS 采集服务依赖 `ws` 与 SQLite 驱动 `better-sqlite3`，安装后需确认对应依赖可用。模拟数据和核心解析不需要串口硬件或采集数据库。

</div>

<div data-sdk-language="python">

### Python 入口 {#python-import}

使用 Python 3.10+，进入含有 `python/` 的解压目录：

```bash
python -m pip install "./python[serial]"
```

```python
from shroom_sdk import Shroom, Framer, decode_frame, resolve_shape, get_layout, ShroomError
```

示例保存为 `.py` 文件，用 `python 文件名.py` 运行。串口需要 pySerial；Mock 与核心解析没有第三方运行依赖。Python 默认同步读取；需要回调时用 `device.on_frame(handler)` / `on_error(handler)`，产品接口见 [Python SDK](../python/README.md)。

</div>

JavaScript SDK 优先通过 npm 安装，下载包和历史 URL 安装方式见[npm 安装说明](./NPM.md)。Python 从 0.6.0 起可用 `python -m pip install "shroom-sdk[serial]"` 从 PyPI 安装，ZIP 解压后本地安装继续可用。浏览器接入见 [前端通讯 API](./FRONTEND-COMMUNICATION.md)，Canvas 见 [渲染 API](./RENDERING.md)。

## 串口 {#serial}

Node.js / 浏览器连接已封装的手套、手部检测垫、人体全身和鞋垫时，优先使用产品入口，SDK 内置协议与映射，应用直接处理 `onData`。鞋垫和人体产品封装要求0.3.0构建；Python 的同名产品入口为 `connect_product / connect_glove / connect_hand_pad`（snake_case 参数），用法见 [Python SDK](../python/README.md)。通用 `connect()` 保留为进阶入口。

通用接入路线是 **查询端口 → 配置连接 → 自动解析 → 错误诊断**。端口查询只枚举系统可见端口，不识别硬件型号；查询、参数校验、打开、运行与关闭都有错误处理入口。

<div data-sdk-language="node">

### Shroom.connectGlove(options) {#node-connect-glove}

**用途**：连接分包手套 `handGloveSegmented`，内置 921600 波特率、130+146 字节配对和左右手映射。浏览器提供同名方法。从 0.4.0 起默认使用分包协议；整包设备使用显式 `connectProduct({ product: 'handGloveFullPacket', ... })`。

| 参数 | 类型 | 必填 / 默认值 |
| --- | --- | --- |
| `side` | `'left' \| 'right' \| 'auto'` | Node 0.5.0可省略或 auto 识别；left/right 用于扫描筛选或手动映射。浏览器与 0.4.0 仍必填 left/right |
| `path` | `string` | Node 可选；源码省略时扫描有效分包，不按端口顺序选设备 |
| `scan` | `{ paths?: string[], timeoutMs?: number, signal?: AbortSignal }` | 仅Node 0.5.0；显式传入时核实串口数据，参数见[扫描 API](#node-scan-product-ports) |
| `port / filters` | 浏览器串口对象 / 筛选数组 | 仅浏览器可选；未给 port 时由用户选择端口 |
| `onData` | `(data) => void` | 可选，在打开前注册的数据回调 |
| `onError` | `(error: ShroomError) => void` | 可选，在打开前注册的运行错误回调 |
| `reconnect` | `boolean \| { intervalMs?: number, maxAttempts?: number }` | 仅 Node；默认开启，间隔 3000ms、最多 3 次；`false` 关闭 |
| `onStateChange` | `(status) => void` | 仅 Node；接收 `state / path / attempt / maxAttempts` |

**返回值**：产品设备的 Promise；产品设备有 `onData / onFrame / onError / state / getDiagnostics() / close()`，Node 还提供 `onStateChange(handler)`。info 含 product、label、side，自动识别后还含 packetType；数据字段见[产品帧](#node-product-data)。具名 connectGlove 是相同入口。

**手动示例**（已发布0.4.0也可用）：

```js
import { Shroom } from './node/index.js';
try {
  const device = await Shroom.connectGlove({
    path: 'COM3', side: 'left',
    onData: (data) => {
      console.log(data.fingers.thumb.raw);
      console.log(data.fingers.index.pulp.raw[0]);
      console.log(data.palm.matrix);
    },
    onError: (error) => console.error(error.code, error.stage, error.suggestion),
  });
  process.once('SIGINT', () => { void device.close().catch(console.error); });
} catch (error) {
  console.error(error.code, error.message, error.suggestion);
}
```

**自动示例**（0.5.0 新增）：

```js
const device = await Shroom.connectGlove({
  // 不填 path/side，识别唯一分包手套；双手都在时可增加 side: 'left' 筛选。
  onData: data => console.log(data.side, data.fingers, data.palm),
  onError: error => console.error(error.code, error.message),
});
```

**注意事项**：一只手一个串口；明确 path+left/right 且无 scan 保持手动映射，省略 path、side 省略/auto 或显式传 scan 时验证真实分包。当前固件 packetType 1=左手、2=右手，不是唯一设备 SN。多个有效匹配报 PORT_AMBIGUOUS、零匹配报 PORT_NOT_FOUND，details.scan 含完整逐口报告；不会随意连接第一个。正式连接与重连固定已发现类型，另一侧有效帧导致 PARSE_FAILED 并停止。浏览器仍需用户手势选口和明确 side，不支持此自动扫描。连接前失败拒绝 Promise，不交给 onError。不接受 baudRate/delimiter/rows/cols/layout 等底层协议覆盖；其他协议使用通用 connect。

### Shroom.connectHandPad(options) {#node-connect-hand-pad}

**用途**：连接手部检测垫 `hand`，内置 1000000 波特率、1024 点、32×32 与 `mat32` 点位映射。

**参数**：可选对象；Node 使用 `path / onData / onError / reconnect / onStateChange`，浏览器使用 `port / filters / onData / onError`。不需要 side，不接受 scan；Node 省略 path 时仍只在恰好一个串口时自动选择，多个口需明确 path。回调与运行错误处理保持产品接口约定。

**返回值**：Node 为 `Promise<NodeProductDevice<HandPadFrame>>`，浏览器为 `Promise<ProductDevice<HandPadFrame>>`；支持相同的产品数据方法，Node 另有状态订阅。具名 `connectHandPad()` 是相同入口。

**示例**：

```js
const device = await Shroom.connectHandPad({
  path: 'COM3',
  onData: (data) => console.log(data.values, data.center),
  onError: (error) => console.error(error.code, error.suggestion),
});
process.once('SIGINT', () => { void device.close().catch(console.error); });
```

**注意事项**：输出已映射，无需应用传波特率、矩阵尺寸或 layout；不接受这些参数覆盖。相对 ADC 不等于 kPa / N，产品入口不执行压力标定。

### Shroom.connectTactileFoot(options?) {#node-connect-tactile-foot}

**用途**：0.7.0 新增的触觉足底入口，规范产品 ID 为 `footVideo`，连接别名为 `foot`；具名 `connectTactileFoot()` 是相同入口。

**参数**：可选 `{ path, side, scan, onData, onError, reconnect, onStateChange }`。Node 可省略 `path/side` 或设置 `side: 'auto'` 自动识别，也可明确指定 `path + side: 'left' / 'right'` 直连；显式 `scan` 会先验证串口。固定 921600 波特率，不接受协议或布局覆盖。

**返回值**：`Promise<NodeProductDevice<TactileFootFrame>>`。包类型 `3=左脚、4=右脚` 始终决定侧别，显式参数只作筛选；不匹配的包不会被重新标记后交付。从 0.7.1 起，`raw / pressure / pressureMatrix` 输出对应脚线序的 60 点原始 ADC，6 列×10 行（rows=10、cols=6）。`imu.raw` 保留 16 字节，`rawPackets` 为含头尾的两包（134/150 字节），保留完整扫描通道。

**示例**：`const device = await Shroom.connectTactileFoot({ path: 'COM3', side: 'left', onData: data => console.log(data.pressure, data.rawPackets) })`；结束时 `await device.close()`。

该协议与 `jqInsole` 独立，详见[触觉足底](./TACTILE-FOOT.md)。Python 暂未接入此产品。

### Shroom.connectProduct(options) {#node-connect-product}

**用途**：按明确的产品标识连接，统一实现产品选择菜单。

**参数**：必填 product，支持分包手套 glove/handGloveSegmented、兼容整包手套 handGloveFullPacket、检测垫 pad/hand、人体 body/humanBody、A版鞋垫 insole/jqInsole，以及 0.7.0 新增的触觉足底 foot/footVideo。Node 分包手套和触觉足底支持省略 side、side: auto 和 scan；整包手套、A版鞋垫仍必须 left/right，检测垫和人体不传 side，其余产品不接受 scan。A版鞋垫另有 protocol: '12bit' / '8bit'（默认12bit）、baudRate（默认921600，限来源列举值）。所有产品支持 path/onData/onError，Node另支持reconnect/onStateChange。鞋垫与人体要求0.3.0，格式详见[鞋垫](./INSOLE.md)、[人体](./HUMAN-BODY.md)。

**返回值**：对应产品设备的 Promise，设备提供 `onData / onFrame / onError / close` 与诊断方法；回调数据类型由产品决定。具名 `connectProduct()` 是相同入口。

**示例**：`await Shroom.connectProduct({ product: 'handGloveSegmented', path: 'COM3', side: 'right', onData: console.log })`。

**注意事项**：快速 readProduct 在 Node 调用本接口，本接口在自动模式复用公开 scanProductPorts，扫描完成后继续原解析与重连链路。别名只用于连接，device.info.product 与 frame.product 使用正式 ID。product 和A版鞋垫 protocol 仍由调用方选择；Node 分包手套和触觉足底可自动确认 side。通用协议继续用 Shroom.connect；Python 的对应方法为 `connect_product / connect_glove / scan_product_ports`，不含触觉足底，见 [Python SDK](../python/README.md)。

### Shroom.listDeviceProducts() {#node-device-products}

**用途**：列出已实现高层连接的产品，供应用构建可直连产品菜单。

**参数**：无。**返回值**：`DeviceProductInfo[]`，每项为 `{ product, label, family, baudRate, payloadLength, sensorPoints, rows, cols }`；具名 `listDeviceProducts()` 是相同入口。

| product | label / family | 波特率 / payload 字节数 | 采样点数 / 产品数据 |
| --- | --- | --- | --- |
| `handGloveSegmented` | 触觉手套（分包）/ glove | 921600 / 130+146=276 | 256 / 两包配对后交付五指、独立指腹与手掌 |
| `handGloveFullPacket` | 触觉手套（整包）/ glove | 921600 / 274 | 256 / 五指、独立指腹与手掌分区 |
| `humanBody` | 人体全身 / body | 1000000 / 1024 | 1024扫描通道 / 10区400真实映射点 |
| `jqInsole` | 鞋垫A版 / insole | 默认921600 / 默认552（8bit为272） | 256扫描通道 / 112真实点；payload不包含魔术头和分包type/index |
| `footVideo` | 触觉足底 / foot（0.7.1） | 921600 / 130+146=276 | 60点原始ADC、6列×10行；左右脚独立线序，16字节原始IMU与完整两包保留；不插值或滤波 |
| `hand` | 手部检测垫 / mat | 1000000 / 1024 | 1024 / 32×32 |

**示例**：`console.log(Shroom.listDeviceProducts())`。

**注意事项**：同步返回，不查询串口，不验证产品是否在线。手套业务点位以 `fingers / palm` 分区为准，不将返回元数据中的 `rows / cols` 作为整只手套的点位规模。旧 `listProducts()` 是通用矩阵产品与线序菜单，旧 `listLayouts()` 是走线表；不要据此假定每个旧产品都已有高层连接封装。

### device.onData(handler) {#node-on-data}

**用途**：订阅高层产品数据；是产品设备 `onFrame()` 的别名。

**参数**：必填同步函数 `(data) => void`。**返回值**：`() => void` 取消订阅函数。

**示例**：`const off = device.onData((data) => console.log(data.pressure))`；结束监听用 `off()`。手套分区字段见下节。

**注意事项**：需要从首帧开始接收时，优先在连接选项中提供 `onData`，它在打开端口前注册。首帧可能早于连接 Promise 完成，回调应直接使用传入的 data，不要假定外层 `const device` 已初始化；需要访问设备时可先声明 `let device` 并判空，或连接后调用 `device.onData()`。`onData` 和 `onFrame` 订阅相同数据，不要重复订阅后再把同一帧计算两次；回调错误为 `CALLBACK_FAILED`，不自动停止采集。

### 产品帧与手套数据 {#node-product-data}

0.3.0新增两类产品：人体使用 `HumanBodyFrame.regions`，鞋垫使用 `InsoleFrame.sensors / imu`。人体 `sourceIndices` 最大可到1023，用Uint16Array保存。鞋垫12bit的 `pressure / pressureMatrix / sensors.raw` 是Uint16Array，绝不可转成Uint8Array；`raw`始终表示ADC原始字节(12bit512/8bit256)。下面原有手套与手垫的Uint8/IMU字节说明仅适用于这两类产品；完整新字段见[人体线序](./HUMAN-BODY.md)和[鞋垫协议](./INSOLE.md)。

| 产品 | 原始压力字段 | 推荐业务字段 | 其他字段 |
| --- | --- | --- | --- |
| `hand` | `raw / pressure`：1024 个扫描顺序 ADC | `pressureMatrix`：1024 个映射 ADC；`values`：归一化 32×32 | 基础 Frame 的矩阵统计与时间戳 |
| `handGloveSegmented` | `raw / pressure`：两包合并的 256 个压力 ADC | `fingers.*.raw / fingers.*.pulp.raw / palm.matrix` | `protocol: segmented / side / packetType / imu.raw`，无 sequence |
| `handGloveFullPacket` | `raw / pressure`：256 个压力 ADC | `fingers.*.raw`：五指主体；`fingers.*.pulp.raw`：独立指腹；`palm.matrix`：72 点手掌 | `side / sequence / packetType / imu.raw`，IMU 原始字节数为 16 |

默认分包手套由首包 `[1, 包类型, 128 个 ADC]`（130 字节）和尾包 `[2, 同包类型, 128 个 ADC, 16 字节 IMU]`（146 字节）组成，每包尾为 `AA 55 03 99`；含帧尾共134/150字节。第一字节1/2是首尾段号，第二字节packetType在当前固件中1=左、2=右，首尾必须一致，既不是采样序号也不是唯一设备SN。每只手套独占一个串口，自动模式据此识别手侧，手动连接仍按显式side映射。两包配对后才交付一帧，无sequence。整包入口保留274字节与原序号，仍需显式side。具体限制见[手套协议](./GLOVE.md)。

**示例**：手套读取 `data.fingers.thumb.raw`、`data.fingers.index.pulp.raw[0]` 和 `data.palm.matrix`。手部检测垫按行列读取 `data.values[y * data.cols + x]`，已映射 ADC 使用 `data.pressureMatrix`；两个产品的原始扫描数据均使用 `data.pressure`。

**五指、独立指腹与手掌**：直接访问 `data.fingers.thumb / index / middle / ring / little`，分别是大拇指、食指、中指、无名指、小拇指，每指主体 4×3、12 点；各指的 `.pulp` 是独立 1×1 指腹分区。`data.palm` 为手掌，声明 rows=5、cols=15，实际行长 `[12, 15, 15, 15, 15]`，共 72 点，不补零。左右手按各自表提取，调用方无需依据对象顺序或切片位置区分手指。

| GloveRegion 字段 | 类型 | 含义 |
| --- | --- | --- |
| `name` | `string` | 中文分区名称 |
| `rows / cols` | `number` | 行数与声明列宽；每行实际长度见 rowLengths |
| `rowLengths` | `number[]` | 按点位表保留的各行点数 |
| `sourceIndices` | `Uint16Array` | 按行展开的 0-based 原扫描索引，用户表的 1-based 点号已减 1 |
| `raw` | `Uint8Array` | 对应源索引的 ADC，无额外补零 |
| `values` | `Float32Array` | raw 按父帧相同 fullScale 归一化 |
| `matrix` | `number[][]` | ADC 按实际行长组成的二维数组，不是归一化值 |

**分区示例**：

```js
const thumb = data.fingers.thumb;
console.log(thumb.raw);                     // 大拇指主体 12 点
console.log(data.fingers.index.pulp.raw[0]); // 食指独立指腹 ADC
console.log(data.palm.matrix);              // 5 行，首行 12 点，其余各 15 点
console.log(data.palm.sourceIndices);       // 对应原 256 点扫描的 0-based 索引
```

五指主体 60 点、独立指腹 5 点、手掌 72 点合计 137 个映射位置，不要求覆盖全部 256 通道。分区直接依照左右手点位表从原始 `pressure` 提取，通过命名属性访问，不从其他矩阵切片获取。五指和手掌的统计由应用按目标分区计算，不把基础 Frame 的矩阵统计解释为这些分区的汇总。分区 `raw / matrix` 是 ADC，分区 `values` 是相对值，都不是力、物理压力或弯曲角度。

点位表中的 `btPacketSize: 128` 仅为表元数据；实际分包组帧由独立 `handGloveSegmented` 适配器完成，不新增蓝牙链路。整包入口仍为 274 字节，两个手套入口均保留 16 字节原始 IMU 和同一套命名分区；Python 的 `GloveFrame` 提供相同分区（`frame.fingers.thumb.pulp`、`frame.palm.row_lengths` 等 snake_case 属性）；通用 Mock 不产生这些分区。

**注意事项**：两种产品的 `raw / pressure`、手套分区的 `raw` 和 `imu.raw` 均为 `Uint8Array`；手套 `palm.matrix` 为按实际行长排列的 ADC 二维数组，分区 `values` 为 `Float32Array`。手部检测垫的 `pressureMatrix` 为 `Uint8Array`、`values` 为 `Float32Array`。产品帧带有 `product` 标识；仅整包手套的 `sequence` 是可能回绕的单字节序号，不是毫秒时间戳；分包帧没有此字段，不能从首尾包标志或包类型字节补造。产品解析和映射已完成，不再调用 `decodeFrame()` 或套用 layout。产品诊断 frameLength 在首个合法包前为 0，之后为 payload 字节数（分包手套两包合计 276 / 整包手套 274 / 手垫 1024），不是映射后的点数。IMU 仅保留原始字节，不承诺单位解析或姿态解算；不提供手势识别或物理压力标定。其他手套协议仍需单独适配。

### Shroom.listPorts() {#node-list-ports}

**用途**：枚举当前机器的串口；具名函数 `listPorts()` 是相同入口。

**参数**：无。**返回值**：`Promise<PortInfo[]>`，无设备时为空数组。字段为 `path`，以及可选的 `manufacturer / serialNumber / vendorId / productId`。

**示例**：

```js
import { Shroom } from './node/index.js';
console.log(await Shroom.listPorts());
```

**注意事项**：需要 `serialport`，无需先激活授权，也不会打开端口。查询失败拒绝为 `ShroomError`；空数组表示没有可见端口。端口路径如 `COM3`、`/dev/ttyUSB0`，查询不会识别产品、协议或线序。将列表展示给用户选择，把选中的 `path` 传给产品入口；插拔后可重新查询，不能默认连接第一项。

### Shroom.scanProductPorts(options?) {#node-scan-product-ports}

**用途**：0.5.0 新增、0.7.0 扩展至触觉足底的 Node 基础 API。实际读取所选产品的串口分包，识别左右手或左右脚；具名 scanProductPorts 是相同入口。需 serialport 和有效 SDK serial 授权，不代替无需授权的 listPorts。

| 参数 | 类型 | 默认值 / 说明 |
| --- | --- | --- |
| product | 'glove' / 'handGloveSegmented' / 'foot' / 'footVideo' | 默认glove；触觉足底从0.7.0起支持 |
| side | 'left' 或 'right' | 可选筛选；省略时接受任一已确认侧别 |
| paths | string[] | 可选候选口；省略时枚举，空数组非法 |
| timeoutMs | number | 每个口的读取窗口，默认1200，范围50–10000ms，不是全部搜索总时长 |
| signal | AbortSignal | 可选取消信号，取消后清理已打开的探测口 |

**返回值**：Promise<ProductPortScanResult>，包含 devices 和 ports。devices 每项含 path、规范product、label、baudRate、side、packetType 和可选驱动 serialNumber。ports 每项含 path/status：matched附device、unrecognized表示未确认、error附ShroomError。side只筛选devices，ports保留全部逐口报告；空devices可正常返回。

```js
import { scanProductPorts } from 'shroom-sdk/node';

const result = await scanProductPorts({ product: 'glove', side: 'left' });
console.table(result.devices); // 仅已确认左手；可交给用户选择 path。
console.table(result.ports);   // 包含未识别口、另一侧设备及占用等失败原因。
```

**识别与释放**：固定921600，只读采样至少3个同侧完整配对；未知/混合侧别不匹配，不扫描波特率，不发送设备命令。所有临时口确认释放后返回，样本不触发业务onData或进入录制。同一SDK中的扫描与托管连接共用路径预约，活跃连接、重连等待和清理未完成的口不会被扫描抢占，报告PORT_BUSY；逻辑连接终止并确认物理端口释放后才解除预约。其他进程占用由系统串口驱动报告。

**错误处理**：逐口打开/读取错误保存在ports；参数、授权、取消及无法确认关闭会拒绝整个调用，取消为USER_CANCELLED、关闭失败为CLOSE_FAILED。自动connectProduct/readProduct使用此报告选择唯一设备，零/多匹配分别报PORT_NOT_FOUND/PORT_AMBIGUOUS，details.scan保留报告；不根据同侧packetType猜测唯一硬件。浏览器WS和Web Serial不提供此API，整包手套与其他产品不参与本次识别。

### Shroom.connect(options) {#node-connect}

**用途**：通用串口进阶入口，打开真实串口并按调用方参数分帧与解码。具名 `connectSerial(options)` 是同一入口；已支持的手套和检测垫优先用上面的产品方法。

**调用方式**：`await Shroom.connect(options)`。

| 参数 | 类型 | 默认值 / 说明 |
| --- | --- | --- |
| `path` | `string` | 可选，未提供时选择第一个端口；生产应用建议明确指定 |
| `baudRate` | `number` | `1000000`，正整数，与设备一致 |
| `delimiter / minLength / maxLength / lockLength` | 分帧选项 | 同 `createFramer()` |
| `rows / cols / points / fullScale / threshold / layout` | 解码选项 | 同 `decodeFrame()` |
| `reconnect` | `boolean \| { intervalMs?: number, maxAttempts?: number }` | 默认 `false`；开启后默认间隔 3000ms、最多 3 次 |
| `onStateChange` | `(status) => void` | 连接状态回调，字段见[自动重连](#node-reconnect) |

**返回值**：`Promise<NodeSerialDevice>`；查询、配置或打开失败以 `ShroomError` 拒绝 Promise，成功后用 `onFrame()` 接收帧。

**示例**：

```js
import { Shroom } from './node/index.js';
const device = await Shroom.connect({ path: 'COM3', baudRate: 1000000, rows: 32, cols: 32 });
device.onError((error) => console.error(error.code, error.stage, error.suggestion));
const unsubscribe = device.onFrame((frame) => console.log(frame.max));
process.once('SIGINT', async () => { unsubscribe(); await device.close(); });
```

**注意事项**：先校验串口、拆帧及解码配置，再打开端口；参数限制见下面对应接口。端口不存在、占用或权限不足时失败；不要与上位机共用同一端口。JS `Device` 没有 `write()` 或 `device.on('error')`，运行期使用 `onError()`。通用 Node 入口默认不重连，可显式启用；产品入口默认启用。

### Node 自动重连与 device.onStateChange(handler) {#node-reconnect}

**用途**：在一次成功连接后，自动恢复意外断开的原串口，保留同一设备句柄、数据订阅及其 WS 服务。五步入口仍是原来的五个函数；重连由 Node 基础串口模块处理。

| 配置或状态 | 说明 |
| --- | --- |
| `reconnect` 省略 | Node 产品入口开启；通用 `connectSerial / Shroom.connect` 关闭 |
| `reconnect: false / true` | 明确关闭或按默认值开启 |
| `reconnect: { intervalMs, maxAttempts }` | 自定义间隔和次数；缺省项为 3000ms、3 次。`intervalMs` 为 1–2147483647 的整数，`maxAttempts` 为 1–1000 的整数；关闭使用 `false` |
| `onStateChange(status)` | 连接选项中的回调；也可用 `device.onStateChange(handler)` 订阅，返回取消订阅函数 |
| `status.state` | `open / reconnecting / error / closed` |
| `status.path` | 此逻辑设备使用的原串口路径 |
| `status.attempt / maxAttempts` | 重连尝试次数和配置上限；收到有效新帧后重置计数 |

```js
const device = await Shroom.connectHandPad({
  path: 'COM3', // 使用 listPorts 查询后用户选定的端口。
  reconnect: { intervalMs: 3000, maxAttempts: 3 },
  onStateChange: status => console.log(status.state, status.attempt),
  onData: data => console.log(data.pressureMatrix),
  onError: error => console.error(error.code, error.message),
});
// 主动退出时取消重连并释放资源：await device.close();
```

首次打开失败拒绝 Promise，不转入后台重试。只有意外断线或读取失败触发恢复；主动 `close()`、授权失效、配置和解析错误不会重连，回调错误不会启动重连。关闭未确认时不能重新抢占端口；重连会清空旧连接的半帧，不混合旧连接的迟到数据。只按原 `path` 重试，不自动匹配换号后的设备；COM 号改变需要重新查询和选择。

每次重连打开最多等待 10 秒，旧连接关闭最多等待 3 秒；这些内部保护时限不作为公开配置。旧端口关闭失败或超时会终止自动重试并保持 `error`，避免仍占用端口时并发打开。重连打开超时按失败次数计入上限。

0.5.0的托管连接在重连等待期间仍保留原path预约，扫描不会抢占它；逻辑连接结束且所有物理连接确认释放后才解锁。自动识别的手套重连仍核对原packetType，另一侧有效帧导致PARSE_FAILED停止，不能静默换设备。

状态回调可能在连接 Promise 完成前触发，不要引用尚未赋值的 `device`。`open` 表示串口已打开，不代表已经有有效产品帧。断线仍通过 `onError` 报告并使当前录制以 `error` 收尾，已接收数据保留；恢复只继续实时取数，新的采集必须由用户重新开始。Web Serial 与浏览器 WS 客户端不支持这些重连配置；Python 使用 `reconnect={"interval": 秒, "max_attempts": 次数}` 与 `on_state_change`，规则相同。

### Shroom.mock(options) {#node-mock}

**用途**：创建模拟设备；具名 `createMockDevice()` 相同。

| 参数 | 类型 | 默认值 / 说明 |
| --- | --- | --- |
| `rows / cols` | `number` | 各 `32`，正整数，总点数不超过 1048576 |
| `fps` | `number` | `30`，有限数值，范围为 `1000 / 2147483647` 至 `1000`（含边界，约 `4.657e-7` 至 `1000`） |
| 其他解码选项 | `DecodeOptions` | 同 `decodeFrame()` |

**返回值**：同步 `Device`，不是 Promise。自动产生帧，结束时必须关闭。

**示例**：

```js
import { Shroom } from './node/index.js';
const device = Shroom.mock({ rows: 32, cols: 32, fps: 20 });
const unsubscribe = device.onFrame((frame) => console.log(frame.timestamp, frame.area));
try { await new Promise((resolve) => setTimeout(resolve, 1000)); }
finally { unsubscribe(); await device.close(); }
```

**注意事项**：JS Mock 没有随机种子参数；可用 `state / getDiagnostics()` 观察模拟设备生命周期和产帧状态。字节与帧计数记录模拟生成量，帧长在首帧前为 0、首帧后为模拟 payload 点数，丢帧为 0，不是串口吞吐。

### device.onFrame(handler) {#node-on-frame}

**用途**：订阅串口或 Mock 每一帧。

**参数**：必填函数 `(frame: Frame) => void`，同步调用。**返回值**：`() => void` 取消订阅函数。

**示例**：已有连接 `device` 时：

```js
const unsubscribe = device.onFrame((frame) => console.log(frame.avg, frame.center));
// 结束这个监听：
unsubscribe();
```

**注意事项**：多个监听可以共存；回调异常会记录，其他监听继续。异步回调不会被等待，避免重计算与无限积累数据。

### device.onError(handler) {#node-on-error}

**用途**：接收连接成功后的串口读取、解析、设备运行或应用帧回调错误。

**参数**：必填函数 `(error: ShroomError) => void`。**返回值**：`() => void` 取消订阅函数；多个监听可以共存。

**示例**：

```js
const offError = device.onError((error) => {
  console.error(error.code, error.stage, error.message, error.suggestion);
  console.log(device.getDiagnostics());
});
// 某个模块不再处理错误时：offError();
```

**注意事项**：查询、配置和首次连接尚未成功时的失败由相应 Promise 拒绝，不会交给这个监听。Node 串口开启重连时，可恢复的读取或断开错误会报告到这里，并由同一设备自动重试；用 `onStateChange` 区分正在恢复和最终失败，不要在每次错误回调中调用 `close()`，否则会取消重连。解析错误、授权失效、清理失败等终止连接；Web Serial 和未开启重连的 Node 连接由应用决定何时重新连接。应用帧回调异常报告为 `CALLBACK_FAILED`、阶段为 `callback`，不会停止设备或中断其他帧订阅，不应当作设备断线。错误回调异常不会阻止其他监听。

### device.state / getDiagnostics() {#node-diagnostics}

**用途**：读取串口或 Mock 的生命周期与诊断快照。

**参数**：无。**返回值**：Node 串口 `state` 为 `'open' | 'reconnecting' | 'closed' | 'error'`；`getDiagnostics()` 同步返回 `{ source, state, bytesReceived, frameCount, droppedCount, frameLength, lastError, status, hint }`，并提供 `reconnectAttempt / reconnectMaxAttempts`。重连中的 `status` 为 `reconnecting`；累计字节与帧数保留，但恢复后的接收状态使用新连接的实际数据判断。Web 和 Mock 没有重连状态。

**示例**：`console.log(device.state, device.getDiagnostics())`。

**注意事项**：读取快照不会等待数据，也不会探测硬件或自动判断根因。字段和 `status` 含义见[设备信息与诊断](#diagnostics)。

### ShroomError / asShroomError / ERROR_CODES {#node-errors}

**用途**：统一识别、记录与展示查询、配置、连接和运行错误；均从 Node.js 或浏览器入口具名导入。

| 接口 | 参数 | 返回值 |
| --- | --- | --- |
| `new ShroomError(code, message, options?)` | 错误码、可读消息；可选 `{ stage, suggestion, details, cause }` | 带对应字段的 `ShroomError` |
| `asShroomError(error, options?)` | 捕获的异常；可选 code、stage、message、suggestion、details 等上下文 | `ShroomError`；已是此类型时原样返回 |
| `ERROR_CODES` | 无 | 公开错误码常量对象 |

**示例**：

```js
import { Shroom, asShroomError } from './node/index.js';
try {
  console.log(await Shroom.listPorts());
  const device = await Shroom.connect({ path: 'COM3', baudRate: 1000000 });
  device.onError((error) => console.error(error.code, error.suggestion));
  process.once('SIGINT', async () => { await device.close(); });
} catch (error) {
  const failure = asShroomError(error);
  console.error(failure.code, failure.stage, failure.message, failure.suggestion);
}
```

**注意事项**：`stage` 指出 `query / configure / connect / read / parse / close / callback` 等失败阶段，`suggestion` 是下一步检查建议，`details` 保留相关上下文，`cause` 保留底层异常。`toJSON()` 返回可序列化字段，不含 cause。`asShroomError()` 默认按 connect 阶段处理，可用 options 明确阶段。不要依赖系统错误消息字符串匹配业务分支；后端网络客户端有自己的错误契约，见[通讯](#communication)。

| 常见 code | 处理方向 |
| --- | --- |
| `INVALID_CONFIG / DEPENDENCY_MISSING` | 修正参数，或按错误提示安装对应依赖（如 `serialport / ws / better-sqlite3`） |
| `PORT_NOT_FOUND / PORT_AMBIGUOUS` | 重新查询并明确选择端口 |
| `PERMISSION_DENIED / PORT_BUSY / CONNECTION_FAILED` | 核对权限、占用、驱动与原始原因 |
| `UNSUPPORTED_ENVIRONMENT / USER_CANCELLED` | 浏览器环境不支持，或用户取消选择；取消可单独静默处理 |
| `DISCONNECTED / READ_FAILED` | 开启重连的 Node 连接按策略恢复，用状态回调区分正在重试和最终失败；其他连接由应用重新连接 |
| `PARSE_FAILED / CLOSE_FAILED` | 终止连接与重试；先处理协议或端口清理问题，再重新连接 |
| `CALLBACK_FAILED` | 检查应用帧回调，设备不一定发生故障 |

### device.close() {#node-close}

**用途**：停止 Mock 或关闭串口，并清理监听。

**参数**：无。**返回值**：`Promise<void>`。**示例**：`await device.close()`。

**注意事项**：在程序退出或组件卸载时显式释放设备。重复调用幂等；主动关闭会取消已安排及进行中的重连，正常关闭后 `state` 为 `closed`，不再产帧。终止故障后可保留 `error` 状态及最近错误供排查。自动重连不等于重新调用此已关闭设备；主动关闭后需要新的连接调用。

### createFramer(options) {#node-framer}

**用途**：把字节流切成 payload，不连接串口、不解码数值。

| 参数 | 类型 | 默认值 |
| --- | --- | --- |
| `delimiter` | `number[] / Uint8Array` | `[0xAA, 0x55, 0x03, 0x99]`，1～64 个 0～255 的整数字节；导出为 `DEFAULT_DELIMITER` |
| `minLength` | `number` | `8`，0～1048576 的整数 |
| `maxLength` | `number` | `8192`，1～1048576 的整数，不小于 minLength |
| `lockLength` | `boolean` | `true` |

**返回值**：带 `push / reset / droppedCount / frameLength` 的切帧器。**示例**：`const framer = createFramer({ minLength: 8 })`。

**注意事项**：非法配置立即抛 `ShroomError`。连续 3 个相同长度后锁定；锁定后不匹配帧丢弃，连续 12 帧新长度可重新锁定。两端分隔符界定完整 payload。

### framer.push(chunk) / reset() {#node-framer-push}

**用途**：追加字节并提取全部完整 payload；重置时清空缓存、锁定和计数。

| 接口 | 参数 | 返回值 |
| --- | --- | --- |
| `push(chunk)` | 必填 `Uint8Array` | `Uint8Array[]`；未成帧时为空数组 |
| `reset()` | 无 | `void` |

**示例**：

```js
import { createFramer, decodeFrame } from './node/index.js';
const framer = createFramer();
const packet = Uint8Array.from([0xAA, 0x55, 0x03, 0x99, 1, 2, 3, 4, 5, 6, 7, 8, 0xAA, 0x55, 0x03, 0x99]);
for (const payload of framer.push(packet)) console.log(decodeFrame(payload, { rows: 2, cols: 4 }));
framer.reset();
```

**注意事项**：跨 chunk 分隔符自动缓存。`droppedCount` 为丢弃帧数，`frameLength` 未锁定时为 `0`。

### decodeFrame(payload, options) {#node-decode-frame}

**用途**：把完整 payload 转为统一 `Frame`，适用于应用自己的数据源。

**参数**：必填 `payload: Uint8Array`，不含分隔符；可选选项见 [Frame 与解码参数](#frame)。

**返回值**：同步 `Frame`；非 raw 排列采用该排列尺寸，缺失采样点填 `0`。

**示例**：

```js
import { decodeFrame } from './node/index.js';
const frame = decodeFrame(Uint8Array.from([0, 64, 128, 255]), { rows: 2, cols: 2 });
console.log(frame.values, frame.center);
```

**注意事项**：提前校验行列、点数、满量程、阈值和布局；非法选项抛 `ShroomError`。`raw` 是 payload 子视图，长期保存应复制。默认满量程对应通常的 0～1；修改 `fullScale` 可能超过 `1`。不做物理压力标定。

### resolveShape(points, options) {#node-resolve-shape}

**用途**：按点数推断矩阵。

| 参数 | 类型 | 必填 / 默认值 |
| --- | --- | --- |
| `points` | `number` | 必填，采样点数 |
| `options.rows / options.cols` | `number` | 可选，应成对提供；两者有效时优先使用 |

**返回值**：`{ rows, cols }`；平方数为方阵，否则为 `1 × points`。

**示例**：`resolveShape(1024)` 得到 `{ rows: 32, cols: 32 }`。

**注意事项**：此函数不读取 `layout`，排列尺寸由 `decodeFrame()` 处理。

### getLayout(name) / listLayouts() {#node-layout}

**用途**：获取或枚举点位排列，不改变 ADC 数值。

| 接口 | 参数 | 返回值 |
| --- | --- | --- |
| `getLayout(name)` | 可选排列名，如 `'mat32'` | `{ rows, cols, perm: Int32Array }`；raw、未提供或未知名称为 `null` |
| `listLayouts()` | 无 | `{ name, label, rows, cols }[]` |

**示例**：

```js
import { getLayout, listLayouts } from './node/index.js';
console.log(listLayouts(), getLayout('mat32').perm[0]);
```

**注意事项**：`perm[显示位置]` 为原始下标，`-1` 表示空点。排列被缓存，不应修改。导出的 `LAYOUTS` 是排列定义集合，产品菜单用下面的接口。

### listProducts() / getProduct(name) {#node-products}

**用途**：提供产品名称、线序和尺寸，面向产品选择菜单。

| 接口 | 参数 | 返回值 |
| --- | --- | --- |
| `listProducts()` | 无 | `ProductInfo[]`，保持菜单顺序 |
| `getProduct(name)` | 产品标识，如 `'fast256'` | `{ name, label, layout, rows, cols }`；未知名称为 `null` |

**示例**：

```js
import { Shroom, listProducts, getProduct } from './node/index.js';
console.log(listProducts());
const product = getProduct('fast256');
if (!product) throw new Error('未知产品');
const device = Shroom.mock({ rows: product.rows, cols: product.cols, layout: product.layout });
await device.close();
```

**注意事项**：导出的 `PRODUCTS` 是原始定义数组。raw 产品使用通用接口时必须传相应 `rows / cols`，查产品不会连接硬件。此表仍用于通用矩阵产品，分包手套走 `connectGlove({ side })`，整包手套走显式 `connectProduct()`，可用协议见 `listDeviceProducts()`，不使用通用 layout；其他协议和多串口整椅采集不因此获得支持。

### Shroom.renderAscii(frame, options) {#node-ascii}

**用途**：转换为终端彩色热力图；具名 `renderAscii()` 相同。

| 参数 | 类型 | 默认值 / 说明 |
| --- | --- | --- |
| `frame` | `Frame` | 必填 |
| `options.width` | `number` | `32`，输出列数不超过原始列数 |
| `options.colormap` | 名称或函数 | `'jet'` |
| `options.gain` | `number` | `1`，仅影响显示 |

**返回值**：包含 ANSI 24 位背景色转义的 `string`，不自行打印。

**示例**：

```js
import { Shroom, decodeFrame } from './node/index.js';
const frame = decodeFrame(Uint8Array.from([0, 64, 128, 255]), { rows: 2, cols: 2 });
console.log(Shroom.renderAscii(frame, { width: 16 }));
```

**注意事项**：终端需支持 ANSI 真彩色；调色板见 [渲染 API](./RENDERING.md#colormap)。Node.js 不提供 Canvas 渲染器。

</div>

<div data-sdk-language="python">

### Shroom.list_ports() {#python-list-ports}

**用途**：枚举系统串口；顶层 `list_ports()` 相同。

**参数**：无。**返回值**：`list[PortInfo]`，没有设备时为空列表。

**字段**：`path / description / manufacturer / serial_number / vendor_id / product_id`；USB ID 是整数或 `None`，与 Node.js 命名及类型不同。

**示例**：

```python
from shroom_sdk import Shroom
print(Shroom.list_ports())
```

**注意事项**：安装 `pyserial`，不是另一个名为 `serial` 的包。查询只枚举系统端口，不自动识别设备协议、波特率或布局；查询失败应捕获结构化错误。

### Shroom.connect(path, **options) {#python-connect}

**用途**：同步打开串口；顶层 `connect()` 返回同一类 `SerialDevice`。

| 参数 | 类型 | 默认值 / 说明 |
| --- | --- | --- |
| `path` | `str \| None` | `None`，仅单个端口时自动选择；多个端口必须指定 |
| `baud_rate` | `int` | `1_000_000`，正整数 |
| `delimiter / min_length / max_length / lock_length` | 分帧选项 | 同 `Framer()` |
| `rows / cols / points / full_scale / threshold / layout` | 解码选项 | 同 `decode_frame()` |

**返回值**：`SerialDevice`，支持 `with`、同步读取、写入与关闭，不是协程。

**示例**：

```python
from shroom_sdk import Shroom
with Shroom.connect("COM3", baud_rate=1_000_000, rows=32, cols=32) as device:
    frame = device.read_frame(timeout=5.0)
    if frame is not None:
        print(frame.max, frame.center)
```

**注意事项**：串口、拆帧和解码参数在打开端口前校验，失败抛结构化 `ShroomError`。配置错误兼容 `ValueError`，I/O 错误兼容 `OSError`；单线程负责读取，`with` 自动释放，没有自动重连。

### Shroom.mock(**options) {#python-mock}

**用途**：创建同步模拟设备；顶层 `mock()` 相同。

| 参数 | 类型 | 默认值 / 说明 |
| --- | --- | --- |
| `rows / cols` | `int` | 各 `32`，正整数 |
| `fps` | `float` | `30`，有限数值，范围为 `1000 / 2147483647` 至 `1000`（含边界，约 `4.657e-7` 至 `1000`） |
| `seed` | `int \| None` | `None`，可控制噪声随机种子 |
| 其他解码选项 | 关键字参数 | 同 `decode_frame()` |

**返回值**：`MockDevice`，按读取或迭代产生帧；只有订阅 `on_frame` 时才启动后台读取线程。

**示例**：

```python
from shroom_sdk import Shroom
with Shroom.mock(rows=32, cols=32, fps=20, seed=1) as device:
    for index, frame in enumerate(device):
        print(frame.max)
        if index >= 19:
            break
```

**注意事项**：没有 JavaScript 的 `onFrame()`，使用同步读取接口。

### device.read_frame(timeout) {#python-read-frame}

**用途**：阻塞等待一帧，适用于串口与 Mock。

**参数**：`timeout: float | None`，默认 `1.0` 秒，有限正数；`None` 持续等待。

**返回值**：`Frame | None`，超时返回 `None`，不代表永久断线。

**示例**：`frame = device.read_frame(timeout=2.0)`，使用前检查是否为 `None`。

**注意事项**：读流或解析失败向调用方抛出结构化异常；超时的 `None` 不代表永久断线，可结合 `get_diagnostics()` 排查。不要在 UI 线程执行阻塞读取。

### device.frames(timeout) / 迭代 {#python-frames}

**用途**：连续产生帧；`for frame in device` 等价于默认 `frames()`。

**参数**：timeout 同 `read_frame()`，默认 `1.0` 秒。**返回值**：`Iterator[Frame]`；超时继续等待，不产出 `None` 或结束。

**示例**：

```python
from shroom_sdk import Shroom
with Shroom.mock() as device:
    for index, frame in enumerate(device.frames(timeout=1.0)):
        print(frame.timestamp)
        if index >= 2:
            break
```

**注意事项**：用 `break`、关闭或中断结束；无限迭代不是后台订阅。

### device.write(data) {#python-write}

**用途**：在真实 `SerialDevice` 上发送调用方提供的协议命令。

**参数**：必填 `data: bytes`，来自实际设备协议。**返回值**：实际写入字节数 `int`。

**示例**：已有连接与协议命令 `command` 时，`written = device.write(command)`。

**注意事项**：Mock 没有 `write()`；SDK 不内置启动、标定或归零命令。写入失败向调用方抛出结构化异常，不能臆造命令。

### device.close() / with {#python-close}

**用途**：标记关闭、释放串口、清空待处理帧。

**参数**：无。**返回值**：`None`。**示例**：`device.close()`，推荐用 `with Shroom.connect(...) as device:`。

**注意事项**：可读取 `closed: bool` 和 `state`；重复关闭不再次操作设备，与 JS 异步关闭不同。正常关闭为 `closed`，读写或解析故障后释放仍保留 `error` 状态与最近错误；关闭本身失败也记录为 error 并抛出。

### device.state / get_diagnostics() {#python-diagnostics}

**用途**：读取 `SerialDevice` 或 `MockDevice` 的生命周期和诊断快照。

**参数**：无。**返回值**：`state` 为 `open / closed / error`；`get_diagnostics()` 返回字典，键为 `source / state / bytes_received / frame_count / dropped_count / frame_length / last_error / status / hint`。

**示例**：`print(device.state, device.get_diagnostics())`；在 `read_frame()` 返回 `None` 时读取快照，可区分当前有无字节和完整帧。

**注意事项**：同步返回，不发起读取或后台采集；诊断字段、状态与限制见[设备信息与诊断](#diagnostics)。

### ShroomError {#python-errors}

**用途**：在同步调用处统一处理查询、配置、打开、读写、解析和关闭失败。

**字段**：`code` 为错误码，`stage` 为发生阶段，`suggestion` 为检查建议，`details` 为上下文；`str(error)` 返回可读消息。

**示例**：

```python
from shroom_sdk import Shroom, ShroomError
try:
    print(Shroom.list_ports())
    with Shroom.connect("COM3", rows=32, cols=32) as device:
        frame = device.read_frame(timeout=2)
        if frame is None:
            print(device.get_diagnostics())
except ShroomError as error:
    print(error.code, error.stage, str(error), error.suggestion)
```

**注意事项**：配置异常兼容 `ValueError`，I/O 异常兼容 `OSError`，缺依赖兼容 `ImportError`，关闭后读写还兼容 `RuntimeError`。错误对象保留 `cause / __cause__`，`to_dict()` 返回不含 cause 的错误快照。没有 JavaScript 的 `onError()` 回调、Promise 或后台线程。读取超时保持返回 `None`。

### Framer(**options) {#python-framer}

**用途**：构造切帧器，不打开设备。

| 参数 | 类型 | 默认值 |
| --- | --- | --- |
| `delimiter` | 字节序列 | `bytes((0xAA, 0x55, 0x03, 0x99))`，1～64 个 0～255 的整数字节；导出为 `DEFAULT_DELIMITER` |
| `min_length` | `int` | `8`，至少 `1` |
| `max_length` | `int` | `8192`，不小于最小长度，不超过 1048576 |
| `lock_length` | `bool` | `True` |

**返回值**：带 `push / reset / dropped_count / frame_length` 的 `Framer`。

**示例**：`framer = Framer(min_length=8, lock_length=True)`。

**注意事项**：空分隔符或非法长度抛 `ValueError`。3 帧锁定、12 帧重新锁定规则与 Node.js 相同。

### framer.push(chunk) / reset() {#python-framer-push}

**用途**：追加字节并返回完整 payload；重置清空缓存和计数。

| 接口 | 参数 | 返回值 |
| --- | --- | --- |
| `push(chunk)` | 必填 `bytes / bytearray / memoryview` | `list[bytes]`，可以为空 |
| `reset()` | 无 | `None` |

**示例**：

```python
from shroom_sdk import Framer, DEFAULT_DELIMITER, decode_frame
framer = Framer()
packet = DEFAULT_DELIMITER + bytes(range(1, 9)) + DEFAULT_DELIMITER
for payload in framer.push(packet):
    print(decode_frame(payload, rows=2, cols=4))
framer.reset()
```

**注意事项**：payload 不含分隔符，为独立快照；错误字节类型抛 `TypeError`。未锁定 `frame_length` 为零。

### decode_frame(payload, **options) {#python-decode-frame}

**用途**：将一个完整 payload 解码为 `Frame`。

**参数**：必填 `bytes / bytearray / memoryview`，不含分隔符；选项见 [Frame 与解码参数](#frame)。

**返回值**：同步 `Frame`，`raw` 为字节快照，`values` 为 `array('f')`。

**示例**：

```python
from shroom_sdk import decode_frame
frame = decode_frame(bytes((0, 64, 128, 255)), rows=2, cols=2)
print(frame.values, frame.center.x)
```

**注意事项**：行列成对；`full_scale` 为有限正数，`threshold` 为有限非负数。非法类型抛 `TypeError`，非法值抛 `ValueError`。mat32 显式使用 `rows=32, cols=32`。

### resolve_shape(points, rows=..., cols=...) {#python-resolve-shape}

**用途**：推断矩阵尺寸。

| 参数 | 类型 | 默认值 / 说明 |
| --- | --- | --- |
| `points` | `int` | 必填，非负整数 |
| `rows / cols` | `int \| None` | 各 `None`，设置时必须成对且为正整数 |

**返回值**：`tuple[int, int]`；平方数为方阵，否则 `(1, points)`。

**示例**：`resolve_shape(1024)` 得到 `(32, 32)`。

**注意事项**：不是 JS 的对象返回值；只设一个维度抛 `ValueError`。

### get_layout(layout, rows, cols) {#python-layout}

**用途**：获取显示位置到原始下标的映射。

| 参数 | 类型 | 必填 / 说明 |
| --- | --- | --- |
| `layout` | `str / Sequence[int] / None` | 必填，raw 或 None 为原序；`mat32` 等内置排列名见 `list_layouts()`；也可给自定义序列 |
| `rows / cols` | `int` | 必填，必须与内置排列的行列一致（如 mat32 为 `32 × 32`、car10 为 `10 × 10`） |

**返回值**：`tuple[int, ...] | None`；原序为 `None`。

**示例**：`get_layout([3, 2, 1, 0], 2, 2)` 得到 `(3, 2, 1, 0)`。

**注意事项**：自定义排列必须是完整 `0 .. rows*cols-1` 置换，不支持 `-1` 空点；未知内置名抛 `ValueError`。内置排列名与 JS 相同，可用 `list_layouts()` / `list_products()` / `get_product()` 查询；内置排列里没有传感器的位置固定为 0。

### Shroom.render_ascii(frame, width=..., gain=...) {#python-ascii}

**用途**：产生纯字符热力图；顶层 `render_ascii()` 相同。

| 参数 | 类型 | 默认值 / 说明 |
| --- | --- | --- |
| `frame` | `Frame` | 必填 |
| `width` | `int` | `32`，正整数，输出列数不超过原始列数 |
| `gain` | `float` | `1.0`，有限正数 |

**返回值**：`str`，使用 ` .:-=+*#%@` 字符，没有 ANSI 颜色。

**示例**：

```python
from shroom_sdk import Shroom, decode_frame
frame = decode_frame(bytes((0, 64, 128, 255)), rows=2, cols=2)
print(Shroom.render_ascii(frame, width=16, gain=1.0))
```

**注意事项**：没有 JS 的 colormap 参数；可选 Matplotlib 图形示例不是 Canvas API。

</div>

### Frame 与解码参数 {#frame}

通用连接、Mock 与直接解码共用下表；Python 用关键字参数，JS 放进 options。JS 高层产品入口固定这些参数，不接受覆盖；其附加字段见[产品帧](./BACKEND-GUIDE.md?language=node#node-product-data)。

| Node.js / Python 参数 | 类型 | 默认值 / 说明 |
| --- | --- | --- |
| `rows / cols` | 正整数 | 成对提供；未提供时按点数推断，非方阵显式指定 |
| `points` | 非负整数 | 默认 payload 长度，只取前 N 字节，不超过 1048576；实际取值截至 payload 长度 |
| `fullScale / full_scale` | 有限正数 | `255`，归一化分母 |
| `threshold` | 有限非负数 | `0.02`，有效点统计阈值 |
| `layout` | 排列 | `'raw'`，两语言支持范围不同 |

| Frame 字段 | JS / Python 类型 | 含义 |
| --- | --- | --- |
| `raw` | `Uint8Array / bytes` | 原始字节，0～255，保持扫描顺序 |
| `values` | `Float32Array / array('f')` | 按显示排列输出，长度为 rows × cols |
| `rows / cols` | `number / int` | 输出矩阵形状 |
| `min / max / avg` | `number / float` | 输出矩阵极值与平均值 |
| `area` | `number / int` | 大于阈值的点数，不是物理面积 |
| `center` | `{ x, y } / Center` | 0～1 重心，无有效点时 (0.5, 0.5) |
| `timestamp` | `number / int` | Unix 毫秒时间戳 |

默认满量程下通常为 0～1 相对 ADC，不是 kPa / N。Python 使用 `center.x / center.y`；后端网络 JSON 不等于此 Frame。

矩阵总点数不超过 1048576。JS 的未知排列名称仍按 raw 回退，Python 会拒绝未知名称；两种语言都不会自动判断真实产品和线序。

### 设备信息与诊断 {#diagnostics}

| Node.js / Python 字段 | 说明 |
| --- | --- |
| `info` | 来源、端口、波特率或 Mock 配置；未推断行列可能为空 |
| `state` | `open / closed / error` 生命周期状态；Node 串口启用重连时还可能为 `reconnecting` |
| `bytesReceived / bytes_received` | 真实串口收到的字节数，为零时优先检查设备发送 |
| `frameCount / frame_count` | 成功切出的 payload 数；字节增长而它不增长时检查协议 |
| `droppedCount / dropped_count` | 无效或不匹配锁定长度的丢帧数 |
| `frameLength / frame_length` | 已锁定帧长，未锁定为零 |
| `lastError / last_error` | 最近错误的可序列化快照，无错误时为 null / None；不含 cause |
| `status / hint` | 当前观测分类和检查建议，来自诊断快照 |

`getDiagnostics() / get_diagnostics()` 对串口与 Mock 均可用；Mock 的字节数和帧数反映模拟生成量，两种语言的帧长都在首帧前为 0、首帧后为模拟 payload 点数，丢帧为 0，不能视为串口吞吐。`status` 为 `waiting-data`（还没有字节）、`waiting-frame`（有字节尚未成帧）、`streaming`（曾产出帧）、`closed` 或 `error`；Node 串口另有 `reconnecting`，其恢复后的收数状态按本次连接判断。Node 的 `reconnectAttempt / reconnectMaxAttempts` 显示当前重连次数和上限，新连接收到有效帧后才清零次数。累计计数和 hint 用于缩小排查范围，不能自动判定根因；`streaming` 不证明设备仍在持续发送，也不代表协议、尺寸与线序都正确。Python 串口 frame_count 统计切帧器接受的 payload 数，批量读取时可能大于已返回给应用的 Frame 数。info 的行列为调用配置，应以实际 Frame 的尺寸为准。真机排错见 [串口参考](./SERIAL.md)。

## 通讯 {#communication}

`serveDevice()` 将当前 SDK 设备发布为独立 WS/HTTP 服务；已有主项目后端则使用 `BackendSdkClient` 查询、控制和订阅。两者协议不同，按实际数据源选择。

<div data-sdk-language="node">

### serveDevice(device, options) {#node-serve-device}

**用途**：订阅已连接设备，在同一端口提供 WS 帧、录制控制和 HTTP 文件下载。快速 `createWS()` 调用本接口；具名 `serveDevice` 与 `Shroom.serveDevice` 相同。

| 参数 | 默认值 / 说明 |
| --- | --- |
| `device` | 必填；提供 `onData(handler)` 或 `onFrame(handler)`，订阅返回取消函数；可提供 `info / onError` |
| `options.port` | `19999`；整数 `0–65535`，`0` 由系统分配端口 |
| `options.host` | `'127.0.0.1'`，默认只监听本机 |
| `options.recordingsDir` | 当前工作目录下 `.shroom-recordings`；新记录保存到该目录的 `recordings.sqlite` |
| `options.allowedOrigins` | 可选明确来源数组，含协议与端口，不支持通配符；跨机监听必填 |
| `options.maxBufferedBytes` | `1048576`，单个 WS 客户端发送缓冲上限，最小 `1024`；超限断开慢客户端 |
| `options.maxQueueFrames` | `1000`，待写入录制帧数上限，整数 `1–100000`；超限以错误结束记录 |

**返回值**：`Promise<DeviceServer>`；`server.url` 为 WS 地址，`server.httpUrl` 为同服务 HTTP 地址，`host / port` 为实际监听值。

```js
const server = await serveDevice(device, { port: 19999 });
console.log(server.url); // 给浏览器 connectStream 使用
```

**授权与生命周期**：真实源先激活 SDK，服务检查读取与 `stream` 权限，开始录制另需 `recording`；内置模拟源可直接验证。设备必须输出有效 Frame/产品帧。创建失败拒绝 Promise；成功后关闭服务会等待文件写完、断开客户端并解除订阅，**不会关闭 device**，调用方仍需 `await device.close()`。`createWS()` 在此基础上增加失败清理和统一关闭设备。

默认只允许本机 HTTP/HTTPS 网页来源，拒绝 `file://` 的空来源；跨机需配置 `host / allowedOrigins`，HTTPS 页面需外部 WSS 代理。服务不内置 TLS，来源校验不替代公网身份认证。

### server 的采集、下载与关闭 {#node-server}

| 方法 | 返回值 / 行为 |
| --- | --- |
| `startRecording({ label })` | `Promise<RecordingSession>`；开始单个标签会话 |
| `stopRecording()` | Promise 等待写入结束，返回本次记录；不停止设备取数 |
| `getRecordingStatus()` | 同步返回最近会话快照；从未开始时为 `null` |
| `listRecordings()` | `Promise<RecordingSession[]>`，按开始时间倒序 |
| `getRecordingUrl(id, { format })` | 同步返回本服务 HTTP URL；校验 UUID 和 `csv / jsonl`，不检查文件存在，也不下载 |
| `close()` | `Promise<void>`；幂等关闭服务并等待录制收尾，不关闭 device |

录制参数、结果字段及错误见[采集基础 API](./STORAGE.md#recording-api)；基础下载必须明确 ID，见[下载与 URL](./STORAGE.md#recording-url)。快速入口的起停函数调用以上同名方法，不另建一套录制实现。

### new BackendSdkClient(options) {#backend-client}

**用途**：创建已有后端网络客户端；浏览器也有同名类。

| 参数 | 类型 | 默认值 / 说明 |
| --- | --- | --- |
| `httpBaseUrl` | `string` | `'http://127.0.0.1:19245'` |
| `wsUrl` | `string` | `'ws://127.0.0.1:19999'`，独立配置 |
| `timeoutMs` | `number` | `10000` 毫秒，有限正数 |
| `headers` | `HeadersInit` | `{}`，HTTP 请求头 |
| `contract / routes` | 对象 | 可选已知契约 / 路由覆盖 |
| `fetchImpl / WebSocketImpl` | 函数 / 构造器 | 环境实现；Node 按需使用 ws |

**返回值**：`BackendSdkClient`，构造不发请求。

**示例**：

```js
import { BackendSdkClient } from './node/index.js';
const client = new BackendSdkClient({ httpBaseUrl: 'http://127.0.0.1:19245', wsUrl: 'ws://127.0.0.1:19999' });
```

**注意事项**：URL 不接受内嵌凭据、query 或 hash。HTTP headers 不等于浏览器 WS 鉴权；鉴权由后端负责。

### client.getContract(options) {#backend-contract}

**用途**：查询并缓存契约，更新 HTTP 路由与订阅消息类型。

**参数**：可选 `{ refresh: boolean }`，默认 `false`。**返回值**：`Promise<BackendContract>`。

**示例**：`await client.getContract()`；强制刷新用 `await client.getContract({ refresh: true })`。

**注意事项**：已有契约且不刷新时不发请求；显式 routes 覆盖优先于契约。

### HTTP 查询接口 {#backend-queries}

**用途**：只读查询状态和元数据。下表均返回 Promise，字段由后端定义。

| 接口 | 参数 | 返回结果 |
| --- | --- | --- |
| `getChannels()` | 无 | 原始 JSON 包 |
| `getWsStatus()` | 无 | 原始 JSON 包 |
| `listDisplaySystems()` | 无 | 原始 JSON 包 |
| `getDisplaySystem(id)` | 必填 string ID | 原始 JSON 包 |
| `listSerialPorts()` | 无 | 已解包数据 |
| `getSerialStatus(role?)` | 可选 string；省略不带 role 查询条件 | 已解包数据 |
| `getCurrentSensor()` | 无 | 已解包数据 |

**示例**：`console.log(await client.listSerialPorts(), await client.getSerialStatus('sit'))`。

**注意事项**：已解包方法将 `{ code: 0, data }` 返回为 data，原始包方法保留外层；非零业务码仍抛错。逐接口说明见 [BackendSdkClient API](../BACKEND.md#queries)。

### 设备与采集控制 {#backend-controls}

**用途**：显式请求后端改变状态，不会自动执行。

| 接口 | 参数 / 默认值 | 返回值 |
| --- | --- | --- |
| `setSensorType(type)` | 必填后端认可的 string 类型 | `Promise<unknown>` 已解包数据 |
| `openSerial(options)` | role='sit'；port/path/portPath 至少一个，按此顺序选择 | 同上 |
| `closeSerial(options?)` | role='sit' | 同上 |
| `startCollection(options?)` | 后端定义对象，默认 {} | 同上 |
| `stopCollection()` | 无 | 同上 |

**示例**：确认设备后，`await client.openSerial({ role: 'sit', port: 'COM3' })`；结束用 `await client.closeSerial({ role: 'sit' })`。

**注意事项**：操作后端机器的端口，写操作不自动重试。采集文件、路径和数据库结构由后端决定。

### client.connectRealtime(options) {#backend-realtime}

**用途**：建立 WS；打开后订阅所选通道。

| 参数 | 类型 | 默认值 |
| --- | --- | --- |
| `channels` | `string / string[]` | `[]`，不自动订阅通道 |
| `timeoutMs` | `number` | 客户端 timeoutMs，毫秒 |
| `protocols` | `string / string[]` | 未指定，WS 子协议 |

**返回值**：立即返回 `WebSocket`，不是 Promise；用 open 事件确认就绪。

**示例**：

```js
import { BackendSdkClient } from './node/index.js';
const client = new BackendSdkClient();
await client.getContract();
client.on('error', (error) => console.error(error.message));
client.on('frame', (frame) => console.log(frame.channelId, frame.value));
client.connectRealtime({ channels: ['sit'] });
process.once('SIGINT', () => client.disconnectRealtime());
```

**注意事项**：没有自动重连。`disconnectRealtime()` 返回 void，清理连接和定时器并发出 close；后端没有发送设备数据时可收到零帧。

### subscribe / unsubscribe / sendRealtime {#backend-subscriptions}

**用途**：在已打开连接上管理订阅或发送 JSON。

| 接口 | 参数 | 返回值 |
| --- | --- | --- |
| `subscribe(channels)` | 必填 string/string[]，非空字符串去重 | void |
| `unsubscribe(channels)` | 同上 | void |
| `sendRealtime(message)` | 必填可 JSON 序列化的值 | void |

**示例**：`client.on('open', () => client.subscribe(['sit', 'back']))`。

**注意事项**：连接未打开时抛错，不排队重放。消息必须符合后端协议。

### on / once / off / removeAllListeners {#backend-events}

**用途**：管理事件监听；均返回客户端自身。

| 接口 | 参数 |
| --- | --- |
| `on(event, handler)` | 必填事件名和函数，持续监听 |
| `once(event, handler)` | 必填事件名和函数，仅一次 |
| `off(event, handler)` | 同一函数，移除对应监听 |
| `removeAllListeners(event?)` | 省略事件名时移除全部 |

| 事件 | 回调参数 |
| --- | --- |
| open | 无 |
| close | 关闭事件 |
| error | Error |
| message | 已解析消息 |
| frame | 后端原始 JSON 帧，批量消息逐帧分发 |
| raw | 无法解析为 JSON 的字符串 |

**示例**：`const handler = (frame) => console.log(frame); client.on('frame', handler); client.off('frame', handler)`。

**注意事项**：HTTP 失败由 Promise 拒绝，不自动触发 error。网络帧不自动归一化、点位重排或转为统一 Frame。

### client.request() / route() {#backend-request}

**用途**：通用 HTTP 请求和命名路由解析。

**调用方式**：`await client.request(routeOrName, options)` / `client.route(name, params)`。

**参数**：request 默认 GET、客户端超时，支持 JSON body、query、routeParams、headers、signal、raw；完整表见 [通用 HTTP 请求](../BACKEND.md#request)。route 必填路由名，路径参数需要齐全。

**返回值**：request 为 `Promise<T>`，route 为编码后的根相对路径 string。

**示例**：`await client.request('serialStatus', { query: { role: 'sit' }, timeoutMs: 5000 })`。

**注意事项**：只允许配置后端下的根相对路径，不接受任意远程 URL。

</div>

<div data-sdk-language="python">

### Python 网络通讯支持范围 {#python-network}

**Python SDK 提供同名的 `BackendSdkClient`：方法为 snake_case（如 `get_contract()`、`connect_realtime()`），HTTP 调用同步返回，实时事件在接收线程上触发。**

Python 可直连串口，在应用中分析和保存。后端已占用设备时，用 `BackendSdkClient` 订阅后端帧并按 [后端 API 契约](../BACKEND.md) 显式调用控制接口；方法名与参数以 [Python SDK](../python/README.md) 为准。

</div>

## 存储 {#storage}

Node.js 快速服务已提供带标签会话录制、SQLite 持久化及 CSV / JSONL 导出，见[数据存储与下载](./STORAGE.md)。新记录写入 `recordingsDir/recordings.sqlite` 的 `sessions / frames` 表，事务批写后才计入 `frameCount`，停止调用等待入库队列排空；下载从 SQLite 分页读取并流式导出。同目录旧版 JSONL 记录仍可读，不自动迁移。以下保留基础帧转换和应用侧保存示例；Python 的 `serve_device / create_ws` 提供相同的服务、录制与导出，并使用同一数据库结构。

<div data-sdk-language="node">

### 帧快照与 JSONL（应用示例） {#node-save}

**用途**：复制帧中的字节视图，再写文件。这不是新增 SDK save() API。

**输入**：Frame。**输出**：应用快照对象和 UTF-8 frames.jsonl。

**示例**：最多缓存 100 帧，短时采集后写入：

```js
import { writeFile } from 'node:fs/promises';
import { Shroom } from './node/index.js';
const snapshots = [];
const device = Shroom.mock({ rows: 32, cols: 32, fps: 20 });
const unsubscribe = device.onFrame((frame) => {
  if (snapshots.length >= 100) return;
  snapshots.push({ timestamp: frame.timestamp, rows: frame.rows, cols: frame.cols,
    raw: Array.from(frame.raw), values: Array.from(frame.values),
    min: frame.min, max: frame.max, avg: frame.avg, area: frame.area, center: { ...frame.center } });
});
try { await new Promise((resolve) => setTimeout(resolve, 2500)); }
finally { unsubscribe(); await device.close(); }
await writeFile('frames.jsonl', snapshots.map((frame) => JSON.stringify(frame)).join('\n') + '\n', 'utf8');
```

**注意事项**：持续采集需要有界队列、批量落盘、文件轮转与磁盘异常处理，不应无限积累帧。

</div>

<div data-sdk-language="python">

### frame.to_dict() {#python-to-dict}

**用途**：生成 JSON 可序列化快照，保留与 JS 一致的字段名。

**参数**：无。**返回值**：dict；raw/values 变为列表，center 变为 `{ "x": ..., "y": ... }`。

**示例**：

```python
import json
from shroom_sdk import decode_frame
frame = decode_frame(bytes((0, 64, 128, 255)), rows=2, cols=2)
print(json.dumps(frame.to_dict(), ensure_ascii=False))
```

**注意事项**：只转换，不写文件或入库；不能直接把含 array/Center 的对象假设成可序列化字典。

### frame.matrix() {#python-matrix}

**用途**：按行列返回二维 values，无需 NumPy。

**参数**：无。**返回值**：`list[list[float]]`，rows 行、cols 列，行优先。

**示例**：`matrix = frame.matrix()`。

**注意事项**：数值是解码后的相对值，不是原始字节或物理单位。

### 写入 JSONL（应用示例） {#python-save}

**用途**：用 Python 标准库保存有限帧，不是 SDK 数据库接口。

**输入**：Frame。**输出**：UTF-8 JSONL 文件。

**示例**：

```python
import json
from shroom_sdk import Shroom
with Shroom.mock(fps=20) as device, open("frames.jsonl", "w", encoding="utf-8") as output:
    for index, frame in enumerate(device):
        output.write(json.dumps(frame.to_dict(), ensure_ascii=False) + "\n")
        if index >= 99:
            break
```

也可运行 CLI：`python -m shroom_sdk --frames 100 --json > frames.jsonl`。省略端口为 Mock；真实设备加 `COM3 --rows 32 --cols 32`。重定向编码由 shell 决定。

**注意事项**：示例会覆盖同名输出文件；真实应用需设计文件名、异常处理与轮转。

</div>

### 数据库与能力边界 {#storage-boundary}

Node.js 快速服务提供本地 SQLite 采集库、会话列表、带标签录制及 CSV / JSONL 导出，并校验对应 SDK 功能授权；不提供业务数据库、通用 SQL 查询、录制回放、力学标定或手势算法。SDK 不依赖 Electron，上位机数据库的表结构与本服务不同，不能直接混用。`BackendSdkClient.startCollection()` 仍只请求已有后端，不是 `stream.startRecording()`；Python 提供对应的 `serve_device`、`connect_stream` 与 `BackendSdkClient`。

长期保存仍需应用制定容量、备份和访问控制策略，并记录协议、产品、点位配置和采样信息。更多见 [数据存储参考](./STORAGE.md)。
