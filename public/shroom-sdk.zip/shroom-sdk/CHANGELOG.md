# Shroom SDK 更新日志

## [0.7.1] - 2026-11-17

- 修正触觉足底原始数据：`raw / pressure / pressureMatrix` 从 256 个扫描通道改为左右脚各自线序对应的 **60 点原始 ADC，6 列×10 行**（rows=10、cols=6）。每点保持 0–255 原值，不插值、滤波、归零或标定。
- 完整扫描通道仍保存在 `rawPackets` 两份完整原包中，原始 IMU 字节和 3=左脚、4=右脚自动识别保持原协议。
- WS 编解码按对应脚的点位表核对 60 点与原包一致性，Node 与网页请一起升级至 0.7.1；同步类型、示例和安装消费验证。Python 产品实现不变。

## [0.7.0] - 2026-11-17

- Node.js 新增触觉足底 `footVideo` / `foot` 与 `connectTactileFoot()`，包类型 3=左脚、4=右脚；支持手动串口及自动发现，按原扫描顺序保留 256 个 uint8 ADC、16 个原始 IMU 字节和含头尾的两份 `rawPackets`。
- 原始字段贯通同版本浏览器 WS、SQLite 录制及 CSV / JSONL 导出；不引入足底抽点、插值、归零、滤波或标定。Python 暂未增加此产品。
- `foot` 的手动 `path + side` 只筛选包内脚侧；省略路径、侧别或显式 `scan` 时按完整分包自动发现，包类型 3/4 不能互换或被参数覆盖。浏览器 Web Serial 直连仍明确传入左右脚，Node 与网页需使用同一版本。
- 五个快速函数及现有手套、鞋垫和人体协议保持原调用方式；新增原始 JSONL 例程、足底协议说明和安装包类型检查。
- 全仓版本元数据同步至 0.7.0；Python 运行功能仍为既有五种产品，本次不发布新的 PyPI 版本。

## [0.6.0] - 2026-11-16

本版本的功能改动只涉及 Python 包。JavaScript 运行代码和五个快速函数与 0.5.0 相同，只有版本常量随全仓版本号变为 0.6.0；JavaScript 的安装说明仍以 npm 上已发布的版本为准。

- Python 包首次以 `shroom-sdk` 为名发布到 PyPI：`python -m pip install "shroom-sdk[serial]"`。ZIP 解压后本地安装继续可用；0.5.0 及更早的 Python 包没有发布到 PyPI。

### Python：与 JavaScript 同一套产品与五步能力

- 增加产品协议与点位映射：`handGloveSegmented`（`glove`）、`handGloveFullPacket`、`hand`（`pad`）、`humanBody`（`body`）、`jqInsole`（`insole`），解析规则、分区和丢弃计数与 JavaScript 实现逐块对照一致。入口为 `connect_product / connect_glove / connect_hand_pad`、`list_device_products()` 与 `create_product_parser()`，产品帧为 `GloveFrame / PadFrame / BodyFrame / InsoleFrame`。
- 分包手套支持与 0.5.0 Node 相同的两种连接方式：`path + side` 手动直连；省略其一或传入 `scan` 时自动发现，唯一匹配才连接，并在重连后继续核对手侧。新增 `scan_product_ports()`：逐口只读采样，按 `packet_type` 1/2 识别左/右手，返回设备列表与逐口诊断，支持取消；扫描样本不进入回调或采集。连接与扫描共用进程内的串口预约，扫描不会打开已被连接占用的串口。
- 产品连接支持 `on_data / on_error / on_state_change` 回调（后台读取线程）和原有的同步 `read_frame()`；默认在原串口上有限重连（每 3 秒、最多 3 次），规则与 Node 相同。通用 `connect()` 可用 `reconnect=` 显式启用。
- 增加五个快速函数 `read_product / create_ws / start_recording / stop_recording / download_recording`，以及基础的 `serve_device`、`connect_stream`、`encode_stream_frame / decode_stream_frame`。WS 数据协议为 `shroom.frame.v1`，Python 服务可被 JavaScript 网页连接，Python 客户端也可连接 Node 服务。
- 增加带标签的 SQLite 录制与 CSV / JSONL 导出，数据库结构与 JavaScript 相同，同一录制目录可先后由两种语言的服务打开；`download_recording(target, path)` 直接保存文件。
- 增加 `BackendSdkClient`、产品模拟 `create_product_mock_device()`、30 种内置点位排列与 `list_layouts / list_products / get_product`、调色板 `shroom / jet / jet_white / grey`。
- 真实设备的数据服务需要 `stream` 授权，采集另需 `recording`；授权校验代码（`license.py`）未改动。
- 数据服务默认只监听本机并校验网页来源与 Host；每个连接只处理一个 HTTP 请求，未读取的请求正文不会被当作后续请求。
- 仍只使用标准库（真实串口需要 `pyserial`）。不提供 Web Serial、Canvas 热力图与产品视图。

### 行为变化（Python）

- `layout` 现在接受全部内置排列名；省略 `rows / cols` 时由排列决定输出行列，数据不足一帧扫描点时报错。此前只接受 `raw` / `mat32`，其他名称报错；`mat32` 的结果不变。
- 设备新增 `on_frame / on_data / on_error`：只有订阅时才启动后台读取线程，不订阅时与之前一样没有后台线程。
- 新协议均以合成数据和 JavaScript 参考实现验证，未连接真实硬件；接入实物前需用对应固件核对。

## [0.5.0] - 2026-11-13

- Node 新增基础 API `scanProductPorts()`：在 921600 波特率下逐口读取分包手套数据，按 `packetType=1/2` 识别左/右手，返回设备列表与逐口诊断。只识别手侧，不将类型字节视为唯一设备编号。
- 保留两种连接方式：明确 `path + side` 时手动直连；分包手套省略路径/手侧或传入 `scan` 时自动发现，唯一匹配才连接。五个快速函数不增加，`readProduct()` 复用基础 `connectProduct()` 与扫描 API。
- 扫描样本不进入业务回调或采集；支持取消、超时、授权撤销与迟到打开的清理。托管连接跨重连保留串口预约，扫描不能抢占它；自动连接遇到另一手侧的有效帧时终止，避免错误线序。
- 更新类型、手动/自动调用示例与分包字段说明。自动识别要求 Node SDK 0.5.0；Web Serial、整包手套及其他产品未增加自动识别。

## [0.4.0] - 2026-11-04

- 增加 `handGloveSegmented`：921600 波特率、130 字节首包与 146 字节尾包按同连接/同包类型合并，输出 256 通道压力、五指/指腹/手掌与 16 字节原始 IMU。
- `glove` 别名及 Node/Web `connectGlove()` 默认改为分包。整包设备继续使用显式 `product: 'handGloveFullPacket'`；五个快速函数不变。
- 分包帧用 `protocol: 'segmented'` 与原始包类型 `packetType` 标识，不伪造 `sequence`。一只手一个串口，显式 side 决定线序，不由 packetType 推断。增加首尾包校验、孤立/重复尾包丢弃、1 秒配对时限与重连缓存清理。
- Node/Web 类型、WS、SQLite、导出和手套产品视图支持分包帧；Python 未新增手套协议。协议仍无 CRC 和帧序号，无法检测所有同类型丢包错配；合成帧验证不代替对应固件与实物验收。

## [0.3.0] - 2026-11-04

- 增加 `body / humanBody` 产品：1024通道原始数据、十块物理矩阵的400点线序与0基源索引。
- 增加 `insole / jqInsole` A版鞋垫：12bit整帧与8bit分包协议、显式脚侧/格式、112真实点坐标、原始ADC与IMU；保留12位精度，不移植显示插值或压力标定。
- 产品参数、帧类型、WS编解码、SQLite采集和CSV/JSONL导出沿用现有五函数；增加半包、坏帧、线序及端到端采集验证。
- Python和现有二维产品视图未新增这两种产品能力。来源代码/合成帧验证不代替对应固件与实物触点验收。

发行版本统一覆盖 Node.js、浏览器和 Python 下载包；不同语言的功能范围以各自文档为准。版本来源为根目录 `package.json`，运行时可通过 `Shroom.version` 或 `shroom_sdk.__version__` 查询。

本文件记录 `shroom-sdk` 的版本。仓库原有 `shroom-backend-sdk@0.2.0` 属于另一套包与接口；其更新日志和代码保留在 `legacy-backend-sdk-0.2.0` 标签，迁移差异见 [MIGRATION.md](https://github.com/liudada118/shroomSDK/blob/main/MIGRATION.md)。两个包的版本号不构成升级或降级关系。

## [0.2.0] - 2026-11-03

### Node.js 串口与快速流程

- Node.js 的 `connectProduct / connectGlove / connectHandPad` 和快速 `readProduct` 默认开启自动重连：意外断线后重试原串口，每 3 秒一次、最多 3 次。可设置 `reconnect: false` 保持关闭，或用 `{ intervalMs, maxAttempts }` 调整策略。通用 `connectSerial / Shroom.connect` 默认仍关闭。
- 新增 `onStateChange` 选项与 `device.onStateChange()`，报告 `open / reconnecting / error / closed` 和尝试次数。重连保留同一设备对象、数据订阅和快速 WS 服务；有效帧到达后才清零尝试次数，诊断按本次连接判断是否恢复收数。
- 首次连接失败仍拒绝 Promise，不进入后台重试。主动关闭、授权失效、解析错误或端口清理失败终止重试；只恢复原 `path`，设备改用新 COM 号时需重新查询并选择。
- 断线将当前 SQLite 采集以 `error` 收尾，保留已采数据供导出；重连只恢复实时数据，重新录制由应用显式调用 `startRecording`。
- 快速接入补充 `listPorts()` 搜索与用户选择串口，使用 `shroom-sdk/node` 基础入口。五个快速函数及其用途不变，README、npm、基础 API 和 AI 接入说明同步更新。

### 兼容范围

- Node 产品连接的默认行为发生变化；需要原先断线后完全由业务处理的项目，升级时显式传入 `reconnect: false`。
- Web Serial、浏览器 WebSocket 客户端和 Python 未增加自动重连。Python 包版本随本次发行同步，语言能力仍以 Python 文档为准。

## [0.1.0] - 2026-10-29

首次建立受管发布基线，汇总当前已有功能，并补齐版本、测试和制品追踪流程。

### Node.js 与浏览器

- 五个快速函数：`readProduct`、`createWS`、`startRecording`、`stopRecording`、`downloadRecording`。只需产品数据时调用取数函数；网页传输、采集与下载按需接入。
- 手套与手部检测垫通过产品适配器解析数据，协议、点位映射和字段校验集中管理；新增产品可扩展适配器与注册表。
- Node.js 服务以 SQLite 保存带标签的采集会话，事务批量入库，停止等待队列写完；支持按记录 ID 导出 CSV / JSONL、异常中断恢复，以及旧 JSONL 记录读取。
- SDK 产品密钥与上位机密钥分开使用，共用授权后台；SDK 不按传感器型号限制授权，仍检查有效期、电脑名额和功能权限。
- 提供连接、配置、授权和采集错误反馈；文档以一步取数及五步调用为主线，补充中文代码注释、驱动入口和 AI 接入说明。

### Python

- 提供通用串口、分帧、矩阵 `Frame`、点位排列、模拟设备、文字热力图和可选绘图示例。
- 提供 SDK 授权与结构化异常、同步帧读取和资源关闭。
- 本版 Python 不提供 JavaScript 的产品五步函数、手套专用解析、WS 采集服务或内置 SQLite 录制。

### 发布管理

- SDK 版本统一来源，Node.js、浏览器与 Python 运行时和包元数据同步校验。
- 固定维护与测试环境的依赖；通过检查与测试后生成带版本号的 ZIP、SHA-256 校验清单、来源清单和发布说明。
- 保留官网兼容下载 URL；版本目录和同名 GitHub Release 禁止静默覆盖。
- 配置 Windows、macOS、Linux 检查；推送匹配版本标签后生成 GitHub Release 草稿，由维护者确认发布。
- 2026-10-30 将源码、测试、版本工具和发布工作流迁入独立的 `shroomSDK` 仓库；SDK 构建不再依赖官网，输出在 `dist/`。官网通过固定的 Git 子模块提交引用同一份 SDK 源码。
- 2026-10-30 增加可由 npm 安装的精简 `.tgz`：只交付压缩运行代码、类型与说明，客户通过 `shroom-sdk/quick-flow` 使用同一套五函数 API；保留源码 ZIP 与 Python 包。
- npm 安装包增加浏览器条件入口，避免前端构建带入 Node.js 串口、服务与 SQLite 模块；安装消费测试覆盖包名导入、五步采集下载、浏览器打包与类型解析。
- 版本附件新增 npm TGZ，并纳入校验和与来源追踪；根目录直接打包设有保护。压缩与安装包管理不改变授权规则，也不提供防破解保证。
- 官网接入改为复制一条安装命令，或直接下载安装包；SDK 免登记下载，真实设备密钥单独申请。快速文档和 AI 上下文默认使用公开包入口与授权 API，示例生成器保留源码 ZIP 相对路径并支持 npm 导入。
- 2026-11-03 整理源码仓库：实现与类型归入 `src/`，演示归入 `examples/`，启动器归入 `scripts/`，AI 与维护说明归入 `docs/`。五个函数及 npm 公开导入保持不变；兼容源码 ZIP 仍使用原有路径。
- 2026-11-03 增加精简安装包的 npm 注册表发布流程，客户使用 `npm install shroom-sdk`；源码根目录继续禁止直接发布，TGZ 下载与历史 URL 安装保持可用。发布后从官方注册表实际安装并比对制品 SHA-512，复验五步采集下载、浏览器入口与类型；授权规则不变。
