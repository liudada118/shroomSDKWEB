import{k as a,l as b}from"./chunks/chunk-UUGZWYGC.js";import"./chunks/chunk-ITZFNJ5E.js";import"./chunks/chunk-JB7NILXR.js";export{b as decodeFrame,a as resolveShape};
