const o="0.4.0";export{o as SDK_VERSION};
