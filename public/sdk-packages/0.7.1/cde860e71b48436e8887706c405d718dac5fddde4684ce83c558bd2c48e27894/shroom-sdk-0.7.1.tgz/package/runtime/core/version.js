const o="0.7.1";export{o as SDK_VERSION};
