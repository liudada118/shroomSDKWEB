const o="0.7.0";export{o as SDK_VERSION};
