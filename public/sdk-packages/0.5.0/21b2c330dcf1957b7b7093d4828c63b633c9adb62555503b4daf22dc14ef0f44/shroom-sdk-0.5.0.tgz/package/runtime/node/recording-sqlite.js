var S=Object.defineProperty;var i=(e,n)=>S(e,"name",{value:n,configurable:!0});import{join as p}from"node:path";import{ShroomError as l}from"../core/errors.js";const _=1;let c;function f(e,n){return new l("RECORDING_WRITE_FAILED",e,{stage:"recording",cause:n})}i(f,"storageError");async function N(){if(c)return c;try{return c=(await import("better-sqlite3")).default,c}catch(e){throw new l("DEPENDENCY_MISSING","SQLite 采集需要安装依赖：npm install better-sqlite3@^11.10.0",{stage:"recording",cause:e,suggestion:"在 SDK 目录安装依赖；Electron 应为自己的运行时重建原生模块。"})}}i(N,"loadDatabase");function L(e,n){return["MODULE_NOT_FOUND","ERR_DLOPEN_FAILED"].includes(e?.code)||/bindings file|NODE_MODULE_VERSION|compiled against a different Node/i.test(e?.message??"")?new l("DEPENDENCY_MISSING","SQLite 原生依赖不可用，请在当前 Node.js 或 Electron 环境重新安装依赖。",{stage:"recording",cause:e}):f(n,e)}i(L,"openingError");function D(e){return{id:e.id,label:e.label,startedAt:e.started_at,endedAt:e.ended_at,frameCount:e.frame_count,status:e.status,...e.product?{product:e.product}:{},...e.side?{side:e.side}:{},...e.source?{source:e.source}:{},...e.error_json?{error:JSON.parse(e.error_json)}:{}}}i(D,"sessionFromRow");async function U(e){const n=await N(),a=p(e,"recordings.sqlite");let s,t;try{s=new n(p(e,"recordings.owner.sqlite"),{timeout:0}),s.pragma("journal_mode = DELETE"),s.exec("BEGIN EXCLUSIVE"),t=new n(a,{timeout:1e3}),t.pragma("journal_mode = WAL"),t.pragma("synchronous = FULL"),t.pragma("foreign_keys = ON");const E=t.pragma("user_version",{simple:!0});if(E!==0&&E!==_)throw new Error("不支持的录制数据库版本。");if(E===0){if(t.prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'").all().length)throw new Error("未识别的数据库结构，不能覆盖。");t.transaction(()=>{t.exec(`
          CREATE TABLE sessions (
            id TEXT PRIMARY KEY,
            label TEXT NOT NULL,
            started_at INTEGER NOT NULL,
            ended_at INTEGER,
            frame_count INTEGER NOT NULL DEFAULT 0,
            status TEXT NOT NULL CHECK (status IN ('recording', 'stopped', 'error')),
            product TEXT,
            side TEXT,
            source TEXT,
            error_json TEXT
          );
          CREATE TABLE frames (
            session_id TEXT NOT NULL REFERENCES sessions(id),
            frame_index INTEGER NOT NULL,
            timestamp REAL NOT NULL,
            row_json TEXT NOT NULL,
            PRIMARY KEY (session_id, frame_index)
          );
          PRAGMA user_version = 1;
        `)})()}const d=JSON.stringify({code:"RECORDING_INTERRUPTED",message:"上次服务退出前未正常停止录制；文件可能不完整。"});t.transaction(()=>{t.prepare(`UPDATE sessions SET status = 'error', ended_at = ?, error_json = ?,
        frame_count = (SELECT COUNT(*) FROM frames WHERE frames.session_id = sessions.id)
        WHERE status = 'recording'`).run(Date.now(),d)})();const R=t.prepare(`INSERT INTO sessions
      (id, label, started_at, ended_at, frame_count, status, product, side, source, error_json)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`),m=t.prepare("INSERT INTO frames (session_id, frame_index, timestamp, row_json) VALUES (?, ?, ?, ?)"),g=t.prepare("UPDATE sessions SET frame_count = frame_count + ? WHERE id = ?"),h=t.prepare("UPDATE sessions SET ended_at = ?, frame_count = ?, status = ?, error_json = ? WHERE id = ?"),O=t.transaction((r,o)=>{for(const u of o)m.run(r,u.index,u.timestamp,u.text);if(g.run(o.length,r).changes!==1)throw new Error("录制会话不存在。")});let T=!1;return{path:a,list(){return t.prepare("SELECT * FROM sessions ORDER BY started_at DESC").all().map(D)},start(r){R.run(r.id,r.label,r.startedAt,null,0,"recording",r.product??null,r.side??null,r.source??null,null)},append(r,o){O(r,o)},finish(r){if(h.run(r.endedAt,r.frameCount,r.status,r.error?JSON.stringify(r.error):null,r.id).changes!==1)throw new Error("录制会话不存在。")},close(){if(T)return;T=!0;const r=[];try{t.close()}catch(o){r.push(o)}try{s.inTransaction&&s.exec("ROLLBACK")}catch(o){r.push(o)}try{s.close()}catch(o){r.push(o)}if(r.length)throw f("关闭录制数据库失败。",r.length===1?r[0]:new AggregateError(r))}}}catch(E){try{t?.open&&t.close()}catch{}try{s?.inTransaction&&s.exec("ROLLBACK")}catch{}try{s?.open&&s.close()}catch{}const d=["SQLITE_BUSY","SQLITE_LOCKED"].includes(E?.code)?"采集目录正被其他服务使用，请关闭该服务或选择另一个目录。":"无法打开录制数据库，请检查依赖、目录权限、磁盘空间和数据库版本。";throw L(E,d)}}i(U,"openRecordingDatabase");async function y(e){const n=await N();let a;try{if(a=new n(e,{readonly:!0,fileMustExist:!0,timeout:1e3}),a.pragma("user_version",{simple:!0})!==_)throw new Error("不支持的录制数据库版本。");return a}catch(s){try{a?.open&&a.close()}catch{}throw L(s,"无法读取录制数据库，请检查文件和权限。")}}i(y,"openRecordingReader");export{_ as RECORDING_DATABASE_VERSION,U as openRecordingDatabase,y as openRecordingReader};
