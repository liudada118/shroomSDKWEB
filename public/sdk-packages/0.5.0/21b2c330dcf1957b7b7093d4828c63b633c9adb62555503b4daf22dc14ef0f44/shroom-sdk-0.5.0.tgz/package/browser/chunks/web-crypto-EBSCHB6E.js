import"./chunk-JB7NILXR.js";var o=globalThis.crypto;export{o as webcrypto};
