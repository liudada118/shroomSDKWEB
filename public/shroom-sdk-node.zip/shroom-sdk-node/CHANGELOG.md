# Shroom SDK 更新日志

## [0.3.0] - 2026-11-04

- 增加 `body / humanBody` 产品：1024通道原始数据、十块物理矩阵的400点线序与0基源索引。
- 增加 `insole / jqInsole` A版鞋垫：12bit整帧与8bit分包协议、显式脚侧/格式、112真实点坐标、原始ADC与IMU；保留12位精度，不移植显示插值或压力标定。
- 产品参数、帧类型、WS编解码、SQLite采集和CSV/JSONL导出沿用现有五函数；增加半包、坏帧、线序及端到端采集验证。
- Python和现有二维产品视图未新增这两种产品能力。来源代码/合成帧验证不代替对应固件与实物触点验收。

发行版本统一覆盖 Node.js、浏览器和 Python 下载包；不同语言的功能范围以各自文档为准。版本来源为根目录 `package.json`，运行时可通过 `Shroom.version` 或 `shroom_sdk.__version__` 查询。

本文件记录 `shroom-sdk` 的版本。仓库原有 `shroom-backend-sdk@0.2.0` 属于另一套包与接口；其更新日志和代码保留在 `legacy-backend-sdk-0.2.0` 标签，迁移差异见 [MIGRATION.md](https://github.com/liudada118/shroomSDK/blob/main/MIGRATION.md)。两个包的版本号不构成升级或降级关系。

## [0.2.0] - 2026-11-03

### Node.js 串口与快速流程

- Node.js 的 `connectProduct / connectGlove / connectHandPad` 和快速 `readProduct` 默认开启自动重连：意外断线后重试原串口，每 3 秒一次、最多 3 次。可设置 `reconnect: false` 保持关闭，或用 `{ intervalMs, maxAttempts }` 调整策略。通用 `connectSerial / Shroom.connect` 默认仍关闭。
- 新增 `onStateChange` 选项与 `device.onStateChange()`，报告 `open / reconnecting / error / closed` 和尝试次数。重连保留同一设备对象、数据订阅和快速 WS 服务；有效帧到达后才清零尝试次数，诊断按本次连接判断是否恢复收数。
- 首次连接失败仍拒绝 Promise，不进入后台重试。主动关闭、授权失效、解析错误或端口清理失败终止重试；只恢复原 `path`，设备改用新 COM 号时需重新查询并选择。
- 断线将当前 SQLite 采集以 `error` 收尾，保留已采数据供导出；重连只恢复实时数据，重新录制由应用显式调用 `startRecording`。
- 快速接入补充 `listPorts()` 搜索与用户选择串口，使用 `shroom-sdk/node` 基础入口。五个快速函数及其用途不变，README、npm、基础 API 和 AI 接入说明同步更新。

### 兼容范围

- Node 产品连接的默认行为发生变化；需要原先断线后完全由业务处理的项目，升级时显式传入 `reconnect: false`。
- Web Serial、浏览器 WebSocket 客户端和 Python 未增加自动重连。Python 包版本随本次发行同步，语言能力仍以 Python 文档为准。

## [0.1.0] - 2026-10-29

首次建立受管发布基线，汇总当前已有功能，并补齐版本、测试和制品追踪流程。

### Node.js 与浏览器

- 五个快速函数：`readProduct`、`createWS`、`startRecording`、`stopRecording`、`downloadRecording`。只需产品数据时调用取数函数；网页传输、采集与下载按需接入。
- 手套与手部检测垫通过产品适配器解析数据，协议、点位映射和字段校验集中管理；新增产品可扩展适配器与注册表。
- Node.js 服务以 SQLite 保存带标签的采集会话，事务批量入库，停止等待队列写完；支持按记录 ID 导出 CSV / JSONL、异常中断恢复，以及旧 JSONL 记录读取。
- SDK 产品密钥与上位机密钥分开使用，共用授权后台；SDK 不按传感器型号限制授权，仍检查有效期、电脑名额和功能权限。
- 提供连接、配置、授权和采集错误反馈；文档以一步取数及五步调用为主线，补充中文代码注释、驱动入口和 AI 接入说明。

### Python

- 提供通用串口、分帧、矩阵 `Frame`、点位排列、模拟设备、文字热力图和可选绘图示例。
- 提供 SDK 授权与结构化异常、同步帧读取和资源关闭。
- 本版 Python 不提供 JavaScript 的产品五步函数、手套专用解析、WS 采集服务或内置 SQLite 录制。

### 发布管理

- SDK 版本统一来源，Node.js、浏览器与 Python 运行时和包元数据同步校验。
- 固定维护与测试环境的依赖；通过检查与测试后生成带版本号的 ZIP、SHA-256 校验清单、来源清单和发布说明。
- 保留官网兼容下载 URL；版本目录和同名 GitHub Release 禁止静默覆盖。
- 配置 Windows、macOS、Linux 检查；推送匹配版本标签后生成 GitHub Release 草稿，由维护者确认发布。
- 2026-10-30 将源码、测试、版本工具和发布工作流迁入独立的 `shroomSDK` 仓库；SDK 构建不再依赖官网，输出在 `dist/`。官网通过固定的 Git 子模块提交引用同一份 SDK 源码。
- 2026-10-30 增加可由 npm 安装的精简 `.tgz`：只交付压缩运行代码、类型与说明，客户通过 `shroom-sdk/quick-flow` 使用同一套五函数 API；保留源码 ZIP 与 Python 包。
- npm 安装包增加浏览器条件入口，避免前端构建带入 Node.js 串口、服务与 SQLite 模块；安装消费测试覆盖包名导入、五步采集下载、浏览器打包与类型解析。
- 版本附件新增 npm TGZ，并纳入校验和与来源追踪；根目录直接打包设有保护。压缩与安装包管理不改变授权规则，也不提供防破解保证。
- 官网接入改为复制一条安装命令，或直接下载安装包；SDK 免登记下载，真实设备密钥单独申请。快速文档和 AI 上下文默认使用公开包入口与授权 API，示例生成器保留源码 ZIP 相对路径并支持 npm 导入。
- 2026-11-03 整理源码仓库：实现与类型归入 `src/`，演示归入 `examples/`，启动器归入 `scripts/`，AI 与维护说明归入 `docs/`。五个函数及 npm 公开导入保持不变；兼容源码 ZIP 仍使用原有路径。
- 2026-11-03 增加精简安装包的 npm 注册表发布流程，客户使用 `npm install shroom-sdk`；源码根目录继续禁止直接发布，TGZ 下载与历史 URL 安装保持可用。发布后从官方注册表实际安装并比对制品 SHA-512，复验五步采集下载、浏览器入口与类型；授权规则不变。
